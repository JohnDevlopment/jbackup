abbrev, _ = engine.get_triggered_abbreviation()
if not abbrev:
    raise RuntimeError("script must be run from abbreviation")

get_attribute = dialog.input_dialog

# abbrev = input("Tag name: ")

# def get_attribute(title: str, message: str, default: str) -> tuple[int, str]:
#     try:
#         line = input(f"{message}: ")
#     except EOFError:
#         return 1, ""

#     return 0, line

class HTMLTag:
    TITLE = "'%s' Tag Attribute"
    CLOSED = True
    ATTRIBUTES: list[tuple[str, str | None]] = []

    def __new__(cls, name: str, *args):
        newcls = {
            'a': _tag_a,
            'id': _tag_a_id,
            'img': _tag_img
        }[name]
        obj = object.__new__(newcls)
        return obj

    def __init__(self, name: str, *args, **kw):
        self._tag_name = name
        self._attributes: list[tuple[str, str]] = []
        for k, v in self.ATTRIBUTES:
            self._set_attribute(k, v or '')

    def _set_attribute(self, name: str, default: str=''):
        code, value = get_attribute(
            self.TITLE % self._tag_name,
            f"Input a value for '{name}'",
            default
        )
        if code or not value:
            return

        attribute = (name, value)
        self._attributes.append(attribute)

    def __str__(self) -> str:
        attributes = [f"{k}=\"{v}\"" for k, v in self._attributes]
        end = f"></{self._tag_name}>" if self.CLOSED else ">"
        return f"<{self._tag_name}{' ' if attributes else ''}{' '.join(attributes)}" + end

class _tag_a(HTMLTag):
    ATTRIBUTES = [
        ('href', None),
        ('id', None)
    ]

class _tag_a_id(HTMLTag):
    ATTRIBUTES = [
        ('id', None)
    ]

class _tag_img(HTMLTag):
    CLOSED = False
    ATTRIBUTES = [
        ('src', None),
        ('id', None),
        ('alt', "image")
    ]

tag = HTMLTag(abbrev)

# print(tag)
engine.set_return_value(str(tag))
